# -*- coding: cp949 -*-
import sys
reload(sys)
sys.setdefaultencoding('cp949')

import os
from flask import Flask, render_template, request, session, escape, redirect, url_for, flash, send_file
import sqlite3


app = Flask(__name__)


@app.route('/login', methods=['POST', 'GET'])
def login():
    email = request.form['email']
    pwd = request.form['password']

    conn = sqlite3.connect("DB/login.db")
    cur = conn.cursor()
    sql =  "select id from login where id='%s' and pwd='%s'"
    sql2=sql
    cur.execute(sql %(email, pwd))
    pw = cur.fetchone()
    try:
        if pw[0] == None:
            qq='�α��ν���'
            return render_template('index.html', sqll=sql2,qq=qq)

        if pw[0] != None:
            qq='�α��μ���'
            return render_template('index.html', sqll=sql2,qq=qq,name=pw[0])
#        return 'Logged in as %s' % escape(session['user'])
    except TypeError:
        qq='����'
        return render_template('index.html', sqll=sql2, qq=qq)

@app.route('/login2', methods=['POST', 'GET'])
def login2():
    email = request.form['email']
    pwd = request.form['password']

    conn = sqlite3.connect("DB/login.db")
    cur = conn.cursor()
    sql = "select count(id) from login where id='"+email+"' and pwd='"+pwd+"'"
    sql2=sql
    cur.execute(sql)
    pw = cur.fetchone()
    try:
        if pw == 0:
            qq='�α��ν���'
            return render_template('index2.html', sqll=sql2,qq=qq)

        if pw == 1:
            qq='�α��μ���'
            return render_template('index2.html', sqll=sql2,qq=qq,name=pw)
#        return 'Logged in as %s' % escape(session['user'])
        else:
            qq='error'
            return render_template('index2.html', sqll=sql2, qq=qq, name=pw)

    except TypeError:
        qq='����'
        return render_template('index.html', sqll=sql2, qq=qq)


@app.route('/')
def hello_world():
    return render_template('index.html')

@app.route('/sql')
def hello_world2():
    return render_template('index2.html')

@app.route('/remediation_list', methods=['POST', 'GET'])
def remediation_list():
    try:
        if request.method == 'POST':
            searchOption = request.form['searchOption']
            keyword = request.form['keyword']

            conn = sqlite3.connect('db/remediation.db')
            conn.row_factory = sqlite3.Row
            cur = conn.cursor()
            sql = "SELECT distinct * FROM remediation where "+searchOption+" like '%" + keyword + "%'"
            cur.execute(sql)
            rows = cur.fetchall()

            return render_template('remediation_list.html', rows=rows,sqll=sql)

        return render_template('remediation_list.html')
    except Exception as e:
        return render_template('remediation_list.html',error=e)

@app.route('/remediation_edit', methods=['POST', 'GET'])
def remediation_edit():
    if request.method == 'POST':
        num = request.form['num']

        conn = sqlite3.connect('DB/remediation.db')
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        sql = "SELECT distinct * FROM remediation where no="+num
        cur.execute(sql)
        rows = cur.fetchall()

        return render_template('remediation_edit.html', rows=rows)

    return render_template('remediation_new.html')

@app.route('/remediation_edit_list', methods=['POST', 'GET'])
def remediation_edit_list():
    if request.method == 'POST':
        searchOption = request.form['searchOption']
        keyword = request.form['keyword']

        conn = sqlite3.connect('DB/remediation.db')
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        sql = "SELECT distinct * FROM remediation where "+searchOption+" like '%" + keyword + "%'"
        cur.execute(sql)
        rows = cur.fetchall()

        return render_template('remediation_edit_list.html', rows=rows)

    return render_template('remediation_edit_list.html')

@app.route('/remediation_new', methods=['GET'])
def remediation_new():

    return render_template('remediation_new.html')

@app.route('/remediation_modi', methods=['POST'])
def remediation_modi():
    no = request.form['num']
    vulname=request.form['vulname']
    cve=request.form['cve']
    client=request.form['client']
    remediation_kor=request.form['remediation_kor']

    conn =sqlite3.connect('DB/remediation.db')
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    sql= "update remediation set vulname= ?, cve=?, client=?, remediation_kor=? where no="+no
    cur.execute(sql,(vulname,cve,client,remediation_kor))
    conn.commit()

    return render_template('remediation_edit_list.html')

@app.route('/remediation_modi_new', methods=['POST'])
def remediation_modi_new():
    vulname=request.form['vulname']
    cve=request.form['cve']
    client=request.form['client']
    remediation_kor=request.form['remediation_kor']

    conn =sqlite3.connect('DB/remediation.db')
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    sql= "insert into remediation (vulname,cve,remediation_ccw,remediation_kor) values (?,?,?,?)"
    cur.execute(sql,(vulname,cve,client,remediation_kor))
    conn.commit()

    return render_template('remediation_edit_list.html')

@app.route('/remediation_file_upload', methods=['GET'])
def remediation_file_upload():

    return render_template('upload.html')



@app.route('/logout')
def logout():
    session.clear()
    return render_template('index.html')


@app.route('/file_upload', methods=['POST'])
def file_upload():
    #try:

        return "<script>alert('upload');</script>"
    #except:
     #   return "<script>alert('error');</script>"

#@app.route('/XSS')
#def xss():

def isLogged():
    try:
        user = session['user']
        return True
    except KeyError:
        user = None
        return False



def alert(msg):
    return "<script>alert('"+str(msg)+"');</script>"

if __name__ == '__main__':


    app.run(host='0.0.0.0', port=8008,debug=True)
